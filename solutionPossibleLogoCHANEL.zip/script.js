let canvas = document.getElementById('chanel');

let rightC = canvas.getContext('2d');
rightC.beginPath();
rightC.arc(300, 200, 70, 0.75, 1.75 * Math.PI);
rightC.lineWidth = 20;
rightC.stroke();

let leftC = canvas.getContext('2d');
leftC.beginPath();
leftC.arc(200, 200, 70, 2.25, 1.25 * Math.PI, true);
leftC.lineWidth = 20;
leftC.stroke();